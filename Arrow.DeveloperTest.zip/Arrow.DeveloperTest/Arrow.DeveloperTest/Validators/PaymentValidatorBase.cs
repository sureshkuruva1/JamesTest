﻿using Arrow.DeveloperTest.Types;
using System;
using System.Collections.Generic;
using System.Text;

namespace Arrow.DeveloperTest.Validators
{
    public abstract class PaymentValidatorBase : IPaymentValidator
    {
        protected static bool IsValidAccount(Account account)
        {
            return account != null;
        }
        public abstract MakePaymentResult IsValid(Account account, MakePaymentRequest paymentRequest);
    }
}
