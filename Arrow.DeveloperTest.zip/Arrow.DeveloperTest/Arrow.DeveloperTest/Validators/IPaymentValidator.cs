﻿using Arrow.DeveloperTest.Types;
using System;
using System.Collections.Generic;
using System.Text;

namespace Arrow.DeveloperTest.Validators
{
    public interface IPaymentValidator
    {
        MakePaymentResult IsValid(Account account, MakePaymentRequest paymentRequest);
    }
}
