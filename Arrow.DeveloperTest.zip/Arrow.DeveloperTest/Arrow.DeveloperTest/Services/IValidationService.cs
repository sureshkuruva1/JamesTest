﻿using Arrow.DeveloperTest.Types;
using System;
using System.Collections.Generic;
using System.Text;

namespace Arrow.DeveloperTest.Services
{
    public interface IValidationService
    {
        MakePaymentResult Validate(PaymentScheme paymentScheme, Account account, MakePaymentRequest paymentRequest);
    }
}
